<?php

return [
    'email' => [
        'required' => 'Email wajib diisi',
        'email' => 'Format email tidak valid',
    ],
    'password' => [
        'required' => 'Password wajib diisi',
    ],
];