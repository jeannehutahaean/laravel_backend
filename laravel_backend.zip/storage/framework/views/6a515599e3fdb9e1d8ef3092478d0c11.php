<nav class="navbar">
    <div class="logo"><a href="/dashboard">Tracking</a></div>
    <ul class="menu">
        <li><a href="/dashboard" class="active">Dashboard</a></li>
    </ul>
</nav>
<?php /**PATH C:\laragon\www\laravel_backend\resources\views/partials/navbar.blade.php ENDPATH**/ ?>