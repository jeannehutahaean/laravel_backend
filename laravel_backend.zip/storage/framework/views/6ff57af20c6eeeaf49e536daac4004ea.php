

<?php $__env->startSection('content'); ?>
<div class="container mx-auto p-4">
    <h1 class="text-2xl font-bold mb-4">Daftar Rute</h1>

    <?php if(session('success')): ?>
        <div class="bg-green-100 text-green-800 p-2 rounded mb-4">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <a href="<?php echo e(route('routes.create')); ?>" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 mb-4 inline-block">+ Tambah Rute</a>

    <table class="w-full table-auto border">
        <thead>
            <tr class="bg-gray-200">
                <th class="p-2 border">ID</th>
                <th class="p-2 border">Shipment ID</th>
                <th class="p-2 border">Nama Lokasi</th>
                <th class="p-2 border">Koordinat</th>
                <th class="p-2 border">Urutan</th>
                <th class="p-2 border">Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $routes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $route): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="text-center">
                <td class="border p-2"><?php echo e($route->id); ?></td>
                <td class="border p-2"><?php echo e($route->shipment_id); ?></td>
                <td class="border p-2"><?php echo e($route->location_name); ?></td>
                <td class="border p-2"><?php echo e($route->latitude); ?>, <?php echo e($route->longitude); ?></td>
                <td class="border p-2"><?php echo e(chr(64 + $route->route_order)); ?></td>
                <td class="border p-2">
                    <a href="<?php echo e(route('routes.edit', $route->id)); ?>" class="text-blue-600 hover:underline">Edit</a> |
                    <form method="POST" action="<?php echo e(route('routes.destroy', $route->id)); ?>" class="inline">
                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                        <button onclick="return confirm('Yakin ingin hapus?')" class="text-red-600 hover:underline">Hapus</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laravel_backend\resources\views/admin/routes/index.blade.php ENDPATH**/ ?>