<!-- Jean Batak -->

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Selamat Datang, <?php echo e(Auth::user()->name); ?></h2>
    <p>Ini adalah dashboard.</p>
    <form action="<?php echo e(route('logout')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <button type="submit">Logout</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laravel_backend\resources\views/dashboard.blade.php ENDPATH**/ ?>