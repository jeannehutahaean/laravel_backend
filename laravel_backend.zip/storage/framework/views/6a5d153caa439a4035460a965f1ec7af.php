<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Tracking System</title>
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body class="<?php echo e(session('dark_mode') ? 'dark-mode' : ''); ?>">
    <?php echo $__env->make('partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>
    <script src="<?php echo e(asset('js/darkmode.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\laragon\www\laravel_backend\resources\views/layouts/main.blade.php ENDPATH**/ ?>