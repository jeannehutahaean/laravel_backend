<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="text-center text-2xl font-bold">Dashboard Monitoring</h1>
    <div class="my-4"></div>

    <div class="row">
        <div class="col-md-12">
            <div id="map" style="height: 400px;" class="mb-3"></div>
        </div>

        <div class="col-md-12">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Driver</th>
                        <th>Vehicle</th>
                        <th>Location</th>
                        <th>Status</th>
                        <th>ETA</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $shipments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shipment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($shipment->driver->name ?? '-'); ?></td>
                            <td><?php echo e($shipment->vehicle->model ?? '-'); ?></td>
                            <td>
                                <?php if($shipment->latestTracking): ?>
                                    <?php echo e($shipment->latestTracking->latitude); ?>, <?php echo e($shipment->latestTracking->longitude); ?>

                                <?php else: ?>
                                    Tidak tersedia
                                <?php endif; ?>
                            </td>
                            <td><?php echo e(ucfirst($shipment->status)); ?></td>
                            <td><?php echo e($shipment->estimated_arrival); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    
    <link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css" />
    <script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>

    <script>
        let map = L.map('map').setView([-6.2, 106.8], 6); // default: Indonesia barat

        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            maxZoom: 18,
        }).addTo(map);

        let markers = [];

        function loadVehicleLocations() {
            fetch("<?php echo e(route('admin.dashboard')); ?>")
                .then(response => response.text())
                .then(html => {
                    const parser = new DOMParser();
                    const doc = parser.parseFromString(html, 'text/html');
                    const tableRows = doc.querySelectorAll("tbody tr");

                    // Bersihkan marker lama
                    markers.forEach(marker => map.removeLayer(marker));
                    markers = [];

                    tableRows.forEach(row => {
                        const latLngText = row.children[2].textContent.trim();
                        if (!latLngText.includes(',')) return;
                        const [lat, lng] = latLngText.split(',').map(Number);

                        const driver = row.children[0].textContent.trim();
                        const vehicle = row.children[1].textContent.trim();
                        const status = row.children[3].textContent.trim();

                        const marker = L.marker([lat, lng]).addTo(map);
                        marker.bindPopup(`<b>${driver}</b><br>${vehicle}<br>Status: ${status}`);
                        markers.push(marker);
                    });
                });
        }

        // Pertama kali
        loadVehicleLocations();

        // Auto refresh tiap 30 detik
        setInterval(loadVehicleLocations, 30000);
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laravel_backend\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>