

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Register</h2>
    <?php if($errors->any()): ?>
        <div style="color: red"><?php echo e($errors->first()); ?></div>
    <?php endif; ?>
    <form action="/register" method="POST">
        <?php echo csrf_field(); ?>
        <input type="text" name="name" placeholder="Nama Lengkap" required><br>
        <input type="email" name="email" placeholder="Email" required><br>
        <input type="password" name="password" placeholder="Password" required><br>
        <input type="password" name="password_confirmation" placeholder="Konfirmasi Password" required><br>
        <button type="submit">Daftar</button>
        <p>Sudah punya akun? <a href="<?php echo e(route('login')); ?>">Login</a></p>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\laravel_backend\resources\views/auth/register.blade.php ENDPATH**/ ?>