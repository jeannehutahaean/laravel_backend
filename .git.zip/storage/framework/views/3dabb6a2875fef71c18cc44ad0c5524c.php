

<?php $__env->startSection('title', 'Notifikasi'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mx-auto px-4 py-8">
        <div class="flex justify-between items-center mb-6">
            <h1 class="text-2xl font-bold text-gray-800">Monitoring dan Notifikasi Pengiriman</h1>
            <div class="flex space-x-2">
                <form method="GET" action="<?php echo e(route('admin.notifications.index')); ?>">
                    <button type="submit" class="px-4 py-2 bg-green-100 text-green-800 rounded-lg text-sm font-medium hover:bg-green-200 transition">
                        <i class="fas fa-sync-alt mr-2"></i>Refresh
                    </button>
                </form>
            </div>
        </div>

        <!-- Summary Cards -->
        <div class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
            <?php if (isset($component)) { $__componentOriginalcc0e87e526d34b7231d6992733fa4eb5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcc0e87e526d34b7231d6992733fa4eb5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.summary-card','data' => ['label' => 'Total Pengiriman','value' => ''.e($summary['total'] ?? 0).'','color' => 'text-blue-800']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('summary-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Total Pengiriman','value' => ''.e($summary['total'] ?? 0).'','color' => 'text-blue-800']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcc0e87e526d34b7231d6992733fa4eb5)): ?>
<?php $attributes = $__attributesOriginalcc0e87e526d34b7231d6992733fa4eb5; ?>
<?php unset($__attributesOriginalcc0e87e526d34b7231d6992733fa4eb5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcc0e87e526d34b7231d6992733fa4eb5)): ?>
<?php $component = $__componentOriginalcc0e87e526d34b7231d6992733fa4eb5; ?>
<?php unset($__componentOriginalcc0e87e526d34b7231d6992733fa4eb5); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginalcc0e87e526d34b7231d6992733fa4eb5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcc0e87e526d34b7231d6992733fa4eb5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.summary-card','data' => ['label' => 'Dalam Perjalanan','value' => ''.e($summary['in_transit'] ?? 0).'','color' => 'text-green-800']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('summary-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Dalam Perjalanan','value' => ''.e($summary['in_transit'] ?? 0).'','color' => 'text-green-800']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcc0e87e526d34b7231d6992733fa4eb5)): ?>
<?php $attributes = $__attributesOriginalcc0e87e526d34b7231d6992733fa4eb5; ?>
<?php unset($__attributesOriginalcc0e87e526d34b7231d6992733fa4eb5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcc0e87e526d34b7231d6992733fa4eb5)): ?>
<?php $component = $__componentOriginalcc0e87e526d34b7231d6992733fa4eb5; ?>
<?php unset($__componentOriginalcc0e87e526d34b7231d6992733fa4eb5); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginalcc0e87e526d34b7231d6992733fa4eb5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcc0e87e526d34b7231d6992733fa4eb5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.summary-card','data' => ['label' => 'Terlambat','value' => ''.e($summary['late'] ?? 0).'','color' => 'text-yellow-800']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('summary-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Terlambat','value' => ''.e($summary['late'] ?? 0).'','color' => 'text-yellow-800']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcc0e87e526d34b7231d6992733fa4eb5)): ?>
<?php $attributes = $__attributesOriginalcc0e87e526d34b7231d6992733fa4eb5; ?>
<?php unset($__attributesOriginalcc0e87e526d34b7231d6992733fa4eb5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcc0e87e526d34b7231d6992733fa4eb5)): ?>
<?php $component = $__componentOriginalcc0e87e526d34b7231d6992733fa4eb5; ?>
<?php unset($__componentOriginalcc0e87e526d34b7231d6992733fa4eb5); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginalcc0e87e526d34b7231d6992733fa4eb5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcc0e87e526d34b7231d6992733fa4eb5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.summary-card','data' => ['label' => 'Penyimpangan','value' => ''.e($summary['deviation'] ?? 0).'','color' => 'text-red-800']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('summary-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Penyimpangan','value' => ''.e($summary['deviation'] ?? 0).'','color' => 'text-red-800']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcc0e87e526d34b7231d6992733fa4eb5)): ?>
<?php $attributes = $__attributesOriginalcc0e87e526d34b7231d6992733fa4eb5; ?>
<?php unset($__attributesOriginalcc0e87e526d34b7231d6992733fa4eb5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcc0e87e526d34b7231d6992733fa4eb5)): ?>
<?php $component = $__componentOriginalcc0e87e526d34b7231d6992733fa4eb5; ?>
<?php unset($__componentOriginalcc0e87e526d34b7231d6992733fa4eb5); ?>
<?php endif; ?>
        </div>

        <!-- Search Box -->
        <div class="mb-6">
            <div class="relative max-w-md">
                <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <i class="fas fa-search text-gray-400"></i>
                </div>
                <input 
                    type="text" 
                    id="searchInput"
                    class="block w-full pl-10 pr-3 py-2 border-2 border-gray-300 rounded-lg bg-white shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500" 
                    placeholder="Cari berdasarkan driver atau order ID..."
                >
            </div>
        </div>

        <!-- Notifications List -->
        <div class="bg-white rounded-lg border-2 border-gray-200 shadow-sm overflow-hidden">
            <div class="p-4 border-b">
                <h2 class="text-lg font-semibold text-gray-800">Aktivitas Terkini</h2>
                <p class="text-sm text-gray-600">Update terakhir: <?php echo e(now()->format('d M Y H:i')); ?></p>
            </div>

            <div class="divide-y divide-gray-200" id="notificationsContainer">
                <?php $__empty_1 = true; $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php echo $__env->make('admin.notifications.partials.card', ['note' => $note], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="p-12 text-center">
                        <div class="mx-auto h-12 w-12 text-gray-400">
                            <i class="fas fa-bell-slash text-3xl"></i>
                        </div>
                        <h3 class="mt-2 text-sm font-medium text-gray-900">Tidak ada notifikasi</h3>
                        <p class="mt-1 text-sm text-gray-500">
                            Tidak ada aktivitas yang perlu diperhatikan saat ini.
                        </p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const searchInput = document.getElementById('searchInput');
            const notificationCards = document.querySelectorAll('.notification-card');

            searchInput.addEventListener('input', function() {
                const searchTerm = this.value.toLowerCase();

                notificationCards.forEach(card => {
                    const driverName = card.getAttribute('data-driver');
                    const orderId = card.getAttribute('data-order');

                    if (driverName.includes(searchTerm) || orderId.includes(searchTerm)) {
                        card.style.display = 'block';
                    } else {
                        card.style.display = 'none';
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/usikrent/laravel_backend/resources/views/admin/notifications/index.blade.php ENDPATH**/ ?>