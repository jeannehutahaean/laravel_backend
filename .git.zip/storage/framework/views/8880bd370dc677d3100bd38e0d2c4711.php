

<?php $__env->startSection('title', 'Laporan Performa Pengiriman'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4 py-6">
    <div class="flex justify-between items-center mb-8">
        <h2 class="text-2xl font-bold text-gray-800">Laporan Pengiriman</h2>
    </div>

    
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6 mb-8">
        <div class="bg-white rounded-lg border-2 border-gray-200 shadow-sm p-6">
            <p class="text-sm font-medium text-gray-600">Total Pengiriman</p>
            <p class="text-3xl font-bold text-gray-900 mt-2"><?php echo e($totalShipments); ?></p>
        </div>

        <div class="bg-white rounded-lg border-2 border-gray-200 shadow-sm p-6">
            <p class="text-sm font-medium text-gray-600">Tepat Waktu</p>
            <p class="text-3xl font-bold text-green-700 mt-2"><?php echo e($onTime); ?></p>
            <p class="text-xs text-gray-500 mt-1">* Hanya yang completed</p>
        </div>

        <div class="bg-white rounded-lg border-2 border-gray-200 shadow-sm p-6">
            <p class="text-sm font-medium text-gray-600">Terlambat</p>
            <p class="text-3xl font-bold text-red-700 mt-2"><?php echo e($late); ?></p>
            <p class="text-xs text-gray-500 mt-1">* Hanya yang completed</p>
        </div>

        <div class="bg-white rounded-lg border-2 border-gray-200 shadow-sm p-6">
            <p class="text-sm font-medium text-gray-600">Rata-rata Waktu</p>
            <p class="text-3xl font-bold text-gray-900 mt-2">
                <?php echo e(floor($avgDeliveryTime / 60)); ?> jam <?php echo e($avgDeliveryTime % 60); ?> menit
            </p>
            <p class="text-xs text-gray-500 mt-1">* Dari pengiriman completed</p>
        </div>

        <div class="bg-white rounded-lg border-2 border-gray-200 shadow-sm p-6">
            <p class="text-sm font-medium text-gray-600">Total Jam Perjalanan</p>
            <p class="text-3xl font-bold text-blue-700 mt-2"><?php echo e(number_format($totalDurationInHours, 2)); ?> jam</p>
            <p class="text-xs text-gray-500 mt-1">* Dari pengiriman completed</p>
        </div>
    </div>

    
    <div class="bg-white rounded-lg border-2 border-gray-200 shadow-sm overflow-hidden">
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-300">
                <thead class="bg-gray-100">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider border-b-2 border-gray-300">No. Order</th>
                        <th class="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider border-b-2 border-gray-300">Tanggal Dibuat</th>
                        <th class="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider border-b-2 border-gray-300">Driver</th>
                        <th class="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider border-b-2 border-gray-300">Kendaraan</th>
                        <th class="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider border-b-2 border-gray-300">Jenis Barang</th>
                        <th class="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider border-b-2 border-gray-300">Total Jam Perjalanan</th>
                        <th class="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider border-b-2 border-gray-300">Status</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    <?php $__empty_1 = true; $__currentLoopData = $shipments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shipment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="hover:bg-gray-50">
                            <td class="px-6 py-4 text-sm font-medium text-gray-900 border-r border-gray-200">
                                <?php echo e('ON-' . str_pad($shipment->id, 4, '0', STR_PAD_LEFT)); ?>

                            </td>
                            <td class="px-6 py-4 text-sm text-gray-700 border-r border-gray-200">
                                <?php echo e(\Carbon\Carbon::parse($shipment->created_at)->translatedFormat('d M Y')); ?><br>
                                <span class="text-gray-500"><?php echo e(\Carbon\Carbon::parse($shipment->created_at)->format('H:i')); ?> WIB</span>
                            </td>
                            <td class="px-6 py-4 text-sm text-gray-700 border-r border-gray-200">
                                <?php echo e($shipment->driver->driver_name ?? '-'); ?>

                            </td>
                            <td class="px-6 py-4 text-sm text-gray-700 border-r border-gray-200">
                                <?php echo e($shipment->vehicle->model ?? '-'); ?>

                            </td>
                            <td class="px-6 py-4 text-sm text-gray-700 border-r border-gray-200">
                                <?php echo e($shipment->goods_type ?? '-'); ?>

                            </td>
                            <td class="px-6 py-4 text-sm text-gray-700 border-r border-gray-200">
                                <?php if($shipment->status_detail === 'completed' && !is_null($shipment->duration_hours)): ?>
                                    <?php echo e($shipment->duration_hours); ?> jam <?php echo e($shipment->duration_minutes); ?> menit
                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </td>
                            <td class="px-6 py-4 text-sm text-gray-700">
                                <div class="flex flex-col space-y-2">
                                    <?php
                                        $status = strtolower($shipment->status_detail ?? 'unknown');
                                        $bg = match($status) {
                                            'waiting' => 'bg-yellow-100 text-yellow-800 border-yellow-200',
                                            'accepted' => 'bg-green-100 text-green-800 border-green-200',
                                            'active' => 'bg-blue-100 text-blue-800 border-blue-200',
                                            'active-paused' => 'bg-orange-100 text-orange-800 border-orange-200',
                                            'done', 'completed' => 'bg-gray-100 text-gray-700 border-gray-200',
                                            default => 'bg-gray-200 text-gray-800 border-gray-300',
                                        };
                                    ?>
                                    <form method="POST" action="<?php echo e(route('admin.report.updateStatus', $shipment->id)); ?>">
                                        <?php echo csrf_field(); ?>
                                        <select name="status" onchange="this.form.submit()" class="text-xs rounded-full border px-2 py-1 <?php echo e($bg); ?>">
                                            <?php $__currentLoopData = ['waiting', 'accepted', 'active','active-paused', 'completed']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($option); ?>" <?php echo e($shipment->status_detail === $option ? 'selected' : ''); ?>>
                                                    <?php echo e(ucfirst(str_replace('-', ' ', $option))); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" class="px-6 py-4 text-center text-sm text-gray-500">
                                Tidak ada data pengiriman.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/usikrent/laravel_backend/resources/views/admin/reports/index.blade.php ENDPATH**/ ?>