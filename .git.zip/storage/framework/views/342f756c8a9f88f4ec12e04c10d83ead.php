<div class="bg-white p-6 rounded-lg border-2 shadow text-center">
    <div class="text-gray-500 text-sm font-medium mb-1"><?php echo e($label); ?></div>
    <div class="text-3xl font-bold <?php echo e($color); ?>"><?php echo e($value); ?></div>
</div>
<?php /**PATH /home/usikrent/laravel_backend/resources/views/components/summary-card.blade.php ENDPATH**/ ?>