<div class="notification-card p-4 hover:bg-gray-50 transition" 
     data-driver="<?php echo e(strtolower($note->driver_name)); ?>" 
     data-order="<?php echo e(strtolower($note->order_id)); ?>">
    <div class="flex justify-between items-center">
        <div>
            <h3 class="text-md font-semibold text-gray-800">
                Pengiriman #<?php echo e($note->order_id); ?>

                <?php if($note->status === 'late'): ?>
                    <span class="ml-2 px-2 py-1 text-xs bg-yellow-100 text-yellow-800 rounded">Terlambat</span>
                <?php elseif($note->status === 'deviation'): ?>
                    <span class="ml-2 px-2 py-1 text-xs bg-red-100 text-red-800 rounded">Penyimpangan</span>
                <?php endif; ?>
            </h3>
            <p class="text-sm text-gray-600 mt-1">
                Driver: <span class="font-medium"><?php echo e($note->driver_name); ?></span> <br>
                Lokasi terakhir: <?php echo e($note->last_position ?? '-'); ?> <br>
                Berangkat: <?php echo e(\Carbon\Carbon::parse($note->departure_time)->format('d M Y H:i')); ?> <br>
                Estimasi Tiba: <?php echo e(\Carbon\Carbon::parse($note->planned_time)->format('d M Y H:i')); ?>

            </p>
            <?php if($note->message): ?>
                <p class="mt-2 text-sm text-red-600 italic"><?php echo e($note->message); ?></p>
            <?php endif; ?>
        </div>
        <div class="text-right text-sm text-gray-500">
            Dibuat: <?php echo e(\Carbon\Carbon::parse($note->created_at)->diffForHumans()); ?>

        </div>
    </div>
</div>
<?php /**PATH /home/usikrent/laravel_backend/resources/views/admin/notifications/partials/card.blade.php ENDPATH**/ ?>