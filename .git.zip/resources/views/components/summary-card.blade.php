<div class="bg-white p-6 rounded-lg border-2 shadow text-center">
    <div class="text-gray-500 text-sm font-medium mb-1">{{ $label }}</div>
    <div class="text-3xl font-bold {{ $color }}">{{ $value }}</div>
</div>
